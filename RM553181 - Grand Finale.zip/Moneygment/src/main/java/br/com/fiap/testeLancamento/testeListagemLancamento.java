package br.com.fiap.testeLancamento;

import java.util.List;

import br.com.fiap.bean.Conta;
import br.com.fiap.bean.Lancamento;
import br.com.fiap.dao.ContaDAO;
import br.com.fiap.dao.OracleContaDAO;
import br.com.fiap.dao.OracleLancamentoDAO;

public class testeListagemLancamento {

	public static void main(String[] args) {
		ContaDAO cDao = new OracleContaDAO();
		
		Conta conta = cDao.buscarPorId(1);
		OracleLancamentoDAO dao = new OracleLancamentoDAO();
		List<Lancamento> lista = dao.listarPorConta(conta);
		
		for(Lancamento l : lista) {
			System.out.println(l.toString());
		}

		
		
	}

}
