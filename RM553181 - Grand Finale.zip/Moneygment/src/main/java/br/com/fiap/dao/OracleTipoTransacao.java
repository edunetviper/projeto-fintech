package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.fiap.bean.Tipo_Transacao;
import br.com.fiap.jdbc.DBManager;

public class OracleTipoTransacao {
		
		private Connection con;
		
		public Tipo_Transacao buscarPorId(int codigoBusca) {
		   
		   	Tipo_Transacao tipoTransacao = null;
	    	PreparedStatement stmt = null;
	    	ResultSet rs = null;
	    	
	    	
	    	try {
	    		con = DBManager.getinstance().obterConexao();
	    		String sql = "SELECT * FROM T_TIPO_TRANSACAO where ID_TIPO_TRANSACAO = ?";
	    		stmt = con.prepareStatement(sql);
	    		stmt.setInt(1, codigoBusca);
	    		rs = stmt.executeQuery();
	    		
	    		if(rs.next()) {
	    			int codigo = rs.getInt("ID_TIPO_TRANSACAO");
	    			String tipo = rs.getString("DS_TIPO_TRANSACAO");
	        		
	    			tipoTransacao = new Tipo_Transacao(codigo, tipo);
	    		}
	    		
	    	}catch(SQLException e) {
	    		e.printStackTrace();
	    	}finally {
	    		try {
	    			con.close();
	    			stmt.close();
	    			rs.close();
	    		}catch(SQLException e) {
	    			e.printStackTrace();
	    		}
	    	}
	    	return tipoTransacao;
		}
}
