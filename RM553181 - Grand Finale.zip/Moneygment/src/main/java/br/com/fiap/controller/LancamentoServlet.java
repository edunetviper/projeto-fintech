package br.com.fiap.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.fiap.bean.Conta;
import br.com.fiap.bean.Lancamento;
import br.com.fiap.dao.LancamentoDAO;
import br.com.fiap.exception.DBException;
import br.com.fiap.factory.DAOFactory;

/**
 * Servlet implementation class LancamentoServlet
 */
@WebServlet("/lancamento")
public class LancamentoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private LancamentoDAO dao;
	
	public void init() throws ServletException{
		super.init();
		dao = DAOFactory.getLancamentoDAO();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			HttpSession session = request.getSession();
			Conta conta = (Conta) session.getAttribute("user");
			String acao = request.getParameter("acao");
			
			switch(acao){
				case "listar":
					listar(request, response, conta);
					break;
				case "abrir-form-edicao":
					abrirFormEdicao(request, response);
					break;
			}
				
	}


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Conta conta = (Conta) session.getAttribute("user");
		String acao = request.getParameter("acao");
		
		switch(acao) {
		case "receita":
			receita(request, response);
			break;
		case "despesa":
			despesa(request, response);
			break;
		case "editarReceita":
			editarReceita(request, response);
			break;
		case "editarDespesa":
			editarDespesa(request, response);
			break;
		case "excluir":
			excluir(request, response, conta);
			break;

		}
		
	}
	
	private void excluir(HttpServletRequest request, HttpServletResponse response, Conta conta) throws ServletException, IOException {
		int codigo = Integer.parseInt(request.getParameter("codigo"));
		try {
			dao.remover(codigo);
			request.setAttribute("msg", "Produto removido!");
		}catch(DBException e) {
			e.printStackTrace();
			request.setAttribute("erro", "Erro ao remover!");
		}
		listar(request, response, conta);
	}

	private void editarReceita(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		try{
			HttpSession session = request.getSession();

			
			Conta conta = (Conta) session.getAttribute("user");
			int codigo = Integer.parseInt(request.getParameter("codigo"));
			double valor = Double.parseDouble(request.getParameter("receita-valor"));
			String descricao = request.getParameter("receita-descricao");
			String categoria = request.getParameter("receita-categoria");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Calendar data = Calendar.getInstance();
			data.setTime(format.parse(request.getParameter("receita-data")));
			
			
			Lancamento lancamento = new Lancamento();
			lancamento.setId(codigo);
			lancamento.setValor(valor);
			lancamento.setDescricao(descricao);
			lancamento.setCategoria(categoria);
			lancamento.setData(data);
			lancamento.setConta(conta);
			lancamento.setTipo("Receita");
			
			dao.atualizar(lancamento);
			
			request.setAttribute("msgReceita", "Receita editada com sucesso");
		}catch(DBException db) {
			db.printStackTrace();
			request.setAttribute("erroReceita", "Erro ao editar receita");
		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("erroReceita","Por favor, valide os dados");
		}
		abrirFormEdicao(request, response);
		
	}
	
	private void editarDespesa(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		try{
			HttpSession session = request.getSession();

			
			Conta conta = (Conta) session.getAttribute("user");
			int codigo = Integer.parseInt(request.getParameter("codigo"));
			double valor = Double.parseDouble(request.getParameter("despesa-valor"));
			String descricao = request.getParameter("despesa-descricao");
			String categoria = request.getParameter("despesa-categoria");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Calendar data = Calendar.getInstance();
			data.setTime(format.parse(request.getParameter("despesa-data")));
			
			
			Lancamento lancamento = new Lancamento();
			lancamento.setId(codigo);
			lancamento.setValor(valor);
			lancamento.setDescricao(descricao);
			lancamento.setCategoria(categoria);
			lancamento.setData(data);
			lancamento.setConta(conta);
			lancamento.setTipo("Despesa");
			
			dao.atualizar(lancamento);
			
			request.setAttribute("msgDespesa", "Despesa editada com sucesso");
		}catch(DBException db) {
			db.printStackTrace();
			request.setAttribute("erroDespesa", "Erro ao editar despesa");
		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("erroDespesa","Por favor, valide os dados");
		}
		abrirFormEdicao(request, response);
		
	}

	private void abrirFormEdicao(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		int id = Integer.parseInt(request.getParameter("codigo"));
		Lancamento lancamento = dao.buscarPorId(id);
		Date data = lancamento.getData().getTime();
		request.setAttribute("dataLancamento", data);
		request.setAttribute("lancamento", lancamento);
		request.getRequestDispatcher("edicao-lancamento.jsp").forward(request, response);
	}

	private void listar(HttpServletRequest request, HttpServletResponse response, Conta conta)
			throws ServletException, IOException {
		List<Lancamento> lista = dao.listarPorConta(conta);
		request.setAttribute("lancamentos", lista);
		request.getRequestDispatcher("listagem-lancamentos.jsp").forward(request, response);
	}
	
	private void receita(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try{
			HttpSession session = request.getSession();

			
			Conta conta = (Conta) session.getAttribute("user");
			double valor = Double.parseDouble(request.getParameter("receita-valor"));
			String descricao = request.getParameter("receita-descricao");
			String categoria = request.getParameter("receita-categoria");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Calendar data = Calendar.getInstance();
			data.setTime(format.parse(request.getParameter("receita-data")));
			
			
			Lancamento lancamento = new Lancamento();
			lancamento.setValor(valor);
			lancamento.setDescricao(descricao);
			lancamento.setCategoria(categoria);
			lancamento.setData(data);
			lancamento.setTipo("Receita");
			lancamento.setConta(conta);
			
			dao.cadastrar(lancamento);
			
			request.setAttribute("msgReceita", "Lancamento cadastrado!");
		}catch(DBException db) {
			db.printStackTrace();
			request.setAttribute("erroReceita", "Erro ao cadastrar");
		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("erroReceita","Por favor, valide os dados");
		}
		request.getRequestDispatcher("lancamentosReceita.jsp").forward(request, response);
	}
	
	public void despesa(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try{
			HttpSession session = request.getSession();

			
			Conta conta = (Conta) session.getAttribute("user");
			double valor = Double.parseDouble(request.getParameter("despesa-valor"));
			String descricao = request.getParameter("despesa-descricao");
			String categoria = request.getParameter("despesa-categoria");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Calendar data = Calendar.getInstance();
			data.setTime(format.parse(request.getParameter("despesa-data")));
			
			
			Lancamento lancamento = new Lancamento();
			lancamento.setValor(valor);
			lancamento.setDescricao(descricao);
			lancamento.setCategoria(categoria);
			lancamento.setData(data);
			lancamento.setTipo("Despesa");
			lancamento.setConta(conta);
			
			dao.cadastrar(lancamento);
			
			request.setAttribute("msgDespesa", "Lancamento cadastrado!");
		}catch(DBException db) {
			db.printStackTrace();
			request.setAttribute("erroDespesa", "Erro ao cadastrar");
		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("erroDespesa","Por favor, valide os dados");
		}
		request.getRequestDispatcher("lancamentos.jsp").forward(request, response);
	}

}
