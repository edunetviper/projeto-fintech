package br.com.fiap.factory;

import br.com.fiap.dao.ContaDAO;
import br.com.fiap.dao.LancamentoDAO;
import br.com.fiap.dao.OracleContaDAO;
import br.com.fiap.dao.OracleLancamentoDAO;

public class DAOFactory {
	public static LancamentoDAO getLancamentoDAO(){
		return new OracleLancamentoDAO();
	}
	
	public static ContaDAO getContaDAO() {
		return new OracleContaDAO();
	}
}
