package br.com.fiap.testeConta;

import java.util.List;

import br.com.fiap.bean.Conta;
import br.com.fiap.dao.OracleContaDAO;

public class testeListagemConta {

	public static void main(String[] args) {
		OracleContaDAO dao = new OracleContaDAO();
		
		List<Conta> contas = dao.listar();
		
		for(Conta conta : contas) {
			System.out.println(conta.toString());
		}

	}

}
