package br.com.fiap.dao;

import java.util.List;

import br.com.fiap.bean.Conta;
import br.com.fiap.bean.Lancamento;
import br.com.fiap.exception.DBException;

public interface LancamentoDAO {
		
    public void cadastrar(Lancamento conta) throws DBException;
    
    public List<Lancamento> listar();

    public List<Lancamento> listarPorConta(Conta conta);
    
    public void atualizar(Lancamento conta) throws DBException;
  
    public void remover(int codigo) throws DBException;
    
    public Lancamento buscarPorId(int codigoBusca);
}
