package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.fiap.bean.Conta;
import br.com.fiap.bean.Tipo_Transacao;
import br.com.fiap.bean.Transacao;
import br.com.fiap.jdbc.DBManager;

public class OracleTransacaoDAO implements TransacaoDAO{
	
	private Connection con;
	
	public void cadastrar(Transacao transacao) throws SQLException, ClassNotFoundException {
		PreparedStatement stmt = null;
		PreparedStatement stmt2 = null;
		PreparedStatement stmt3 = null;
		
		try {
			con = DBManager.getinstance().obterConexao();
			con.setAutoCommit(false);
			String sql = "INSERT INTO T_TRANSACAO (id_transacao, dt_transacao, vl_transacao, ds_outros_detalhes, id_conta_destino, id_conta, id_tipo_transacao) VALUES (SQ_TRANSACAO.NEXTVAL, ?, ?, ?, ?, ?, ?)";
			stmt = con.prepareStatement(sql);
			
			java.sql.Date data = new java.sql.Date(transacao.getData().getTimeInMillis());
			stmt.setDate(1, data);
			stmt.setDouble(2, transacao.getValor());
			stmt.setString(3, transacao.getDetalhes());
			stmt.setInt(4, transacao.getContaDestino().getIdConta());
			stmt.setInt(5, transacao.getContaOrigem().getIdConta());
			stmt.setInt(6, transacao.getTipoTransacao().getId());
			stmt.executeUpdate();
			con.commit();
			
			stmt2 = con.prepareStatement("UPDATE T_CONTA SET ds_balanco = ds_balanco - ? WHERE id_conta = ?");
			stmt2.setDouble(1, transacao.getValor());
			stmt2.setInt(2, transacao.getContaOrigem().getIdConta());
			stmt2.executeUpdate();
			
			stmt3 = con.prepareStatement("UPDATE T_CONTA SET ds_balanco = ds_balanco + ? WHERE id_conta = ?");
			stmt3.setDouble(1, transacao.getValor());
			stmt3.setInt(2, transacao.getContaDestino().getIdConta());
			stmt3.executeUpdate();

			con.commit();
		}catch(SQLException se) {
			con.rollback();
			System.err.println("A transacao não foi realizada");
			se.printStackTrace();
		}finally {
			try {
				con.close();
				stmt.close();
				stmt2.close();
				stmt3.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
	};
    
    public List<Transacao> listar(){
    	List<Transacao> lista = new ArrayList<Transacao>();
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {

    		con = DBManager.getinstance().obterConexao();
    		String sql = "SELECT * FROM T_TRANSACAO";
    		stmt = con.prepareStatement(sql);
    		rs = stmt.executeQuery();
    		OracleContaDAO contaDAO = new OracleContaDAO();
    		OracleTipoTransacao tipoDao = new OracleTipoTransacao();
    		
    		while(rs.next()) {
    			Conta contaOrigem = null;
    			Conta contaDestino = null;
    			Transacao transacao = null;
    			Tipo_Transacao tipo = null;
    			int codigo = rs.getInt("ID_TRANSACAO");
    			int idTipo  = rs.getInt("ID_TIPO_TRANSACAO");
    			Double valor = rs.getDouble("VL_TRANSACAO");
    			String detalhes = rs.getString("DS_OUTROS_DETALHES");
    			int idContaOrigem = rs.getInt("ID_CONTA");
    			int idContaDestino = rs.getInt("ID_CONTA_DESTINO");
    			java.sql.Date data = rs.getDate("DT_TRANSACAO");
    			Calendar dataTransacao = Calendar.getInstance();
    			dataTransacao.setTimeInMillis(data.getTime());
    			contaOrigem = contaDAO.buscarPorId(idContaOrigem);
    			contaDestino = contaDAO.buscarPorId(idContaDestino);
    			tipo = tipoDao.buscarPorId(idTipo);
    			
    			transacao = new Transacao(codigo, dataTransacao, valor, contaOrigem, contaDestino, tipo, detalhes);
    			
    			lista.add(transacao);
    		}
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    			rs.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	return lista;
    }

	@Override
	public Transacao buscarPorId(int codigoBusca) {
		Transacao transacao = null;
		OracleContaDAO contaDAO = new OracleContaDAO();
		OracleTipoTransacao tipoDao = new OracleTipoTransacao();
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		stmt = con.prepareStatement("SELECT * FROM T_TRANSACAO WHERE ID_TRANSACAO = ?");
    		stmt.setInt(1, codigoBusca);
    		rs = stmt.executeQuery();
    		
    		if(rs.next()) {
    			Conta contaOrigem = null;
    			Conta contaDestino = null;
    			Tipo_Transacao tipo = null;
    			int codigo = rs.getInt("ID_TRANSACAO");
    			int idTipo  = rs.getInt("ID_TIPO_TRANSACAO");
    			Double valor = rs.getDouble("VL_TRANSACAO");
    			String detalhes = rs.getString("DS_OUTROS_DETALHES");
    			int idContaOrigem = rs.getInt("ID_CONTA");
    			int idContaDestino = rs.getInt("ID_CONTA_DESTINO");
    			java.sql.Date data = rs.getDate("DT_TRANSACAO");
    			Calendar dataTransacao = Calendar.getInstance();
    			dataTransacao.setTimeInMillis(data.getTime());
    			contaOrigem = contaDAO.buscarPorId(idContaOrigem);
    			contaDestino = contaDAO.buscarPorId(idContaDestino);
    			tipo = tipoDao.buscarPorId(idTipo);
    			
    			transacao = new Transacao(codigo, dataTransacao, valor, contaOrigem, contaDestino, tipo, detalhes);

    		}
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    			rs.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	return transacao;
	};
	

}	
