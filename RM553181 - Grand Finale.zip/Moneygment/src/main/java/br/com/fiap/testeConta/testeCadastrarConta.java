package br.com.fiap.testeConta;

import java.util.Calendar;

import br.com.fiap.bean.Conta;
import br.com.fiap.dao.OracleContaDAO;

public class testeCadastrarConta {

	public static void main(String[] args) {
		OracleContaDAO dao = new OracleContaDAO();
		
		Conta conta = new Conta();
		
		conta.setNome("Santos Neto");
		conta.setCpf("66688899904");
		conta.setEmail("dinho@fiap.com");
		conta.setSenha("!qa@ws#ed");
		conta.setTelefone("11940028999");
		conta.setDataCriacao(Calendar.getInstance());
		
		;
		
		dao.cadastrar(conta);
		
		System.out.println("Conta cadastrada!");
	}

}
