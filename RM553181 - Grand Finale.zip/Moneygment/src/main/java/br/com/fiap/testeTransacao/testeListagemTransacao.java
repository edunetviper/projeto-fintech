package br.com.fiap.testeTransacao;

import java.util.List;

import br.com.fiap.bean.Transacao;
import br.com.fiap.dao.OracleTransacaoDAO;

public class testeListagemTransacao {

	public static void main(String[] args) {
		OracleTransacaoDAO dao = new OracleTransacaoDAO();
		List<Transacao> lista = dao.listar();
		
		for(Transacao t : lista) {
			System.out.println(t.toString());
		}

	}

}
