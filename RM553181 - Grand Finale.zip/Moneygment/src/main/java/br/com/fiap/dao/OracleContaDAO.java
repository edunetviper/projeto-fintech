package br.com.fiap.dao;

import br.com.fiap.bean.Conta;
import br.com.fiap.jdbc.DBManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class OracleContaDAO implements ContaDAO{
	
	private Connection con;
	
    public void cadastrar(Conta conta) {
    	PreparedStatement stmt = null;
    	try {
    		con = DBManager.getinstance().obterConexao();
    		String sql = "INSERT INTO t_conta(id_conta, nm_usuario, nr_cpf, ds_balanco, ds_email, ds_senha, nr_telefone, dt_criacao) VALUES (SQ_CONTA.NEXTVAL, ?, ?, ?, ?, ?, ?, ?)";
    		stmt = con.prepareStatement(sql);
    		stmt.setString(1, conta.getNome());
    		stmt.setString(2, conta.getCpf());
    		stmt.setDouble(3, conta.getSaldo());
    		stmt.setString(4, conta.getEmail());
    		stmt.setString(5, conta.getSenha());
    		stmt.setString(6, conta.getTelefone());
    		java.sql.Date data = new java.sql.Date(conta.getDataCriacao().getTimeInMillis());
    		stmt.setDate(7, data);
    		
    		stmt.executeUpdate();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    };
    
    public List<Conta> listar(){
    	List<Conta> lista = new ArrayList<Conta>();
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		stmt = con.prepareStatement("SELECT * FROM T_CONTA");
    		rs = stmt.executeQuery();
    		
    		while(rs.next()) {
    			int id = rs.getInt("id_conta");
    			String nome = rs.getString("nm_usuario");
    			String cpf = rs.getString("nr_cpf");
    			Double saldo = rs.getDouble("ds_balanco");
    			String email = rs.getString("ds_email");
    			String senha = rs.getString("ds_senha");
    			String telefone = rs.getString("nr_telefone");
    			java.sql.Date data = rs.getDate("dt_criacao");
    			Calendar dataCriacao = Calendar.getInstance();
    			dataCriacao.setTimeInMillis(data.getTime());
    			
    			Conta conta = new Conta(nome, senha, cpf, email, telefone, dataCriacao, saldo, id);
    			
    			lista.add(conta);
    		}
    		
    	}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				stmt.close();
				con.close();
				rs.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
    	return lista;
    };
    
    public void remover(int codigo) {
    	
    	PreparedStatement stmt = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		String sql = "DELETE FROM T_CONTA WHERE id_conta = ?";
    		stmt = con.prepareStatement(sql);
    		stmt.setInt(1, codigo);
    		stmt.executeUpdate();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	
    };
    
    public void atualizar(Conta conta) {
    	
    	PreparedStatement stmt = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		String sql = "UPDATE T_CONTA SET nm_usuario = ?, nr_cpf = ?, ds_balanco = ?, ds_email = ?, ds_senha = ?, nr_telefone = ?, dt_criacao = ? WHERE id_conta = ?";
    		stmt = con.prepareStatement(sql);
    		stmt.setString(1, conta.getNome());
    		stmt.setString(2, conta.getCpf());
    		stmt.setDouble(3, conta.getSaldo());
    		stmt.setString(4, conta.getEmail());
    		stmt.setString(5, conta.getSenha());
    		stmt.setString(6, conta.getTelefone());
    		java.sql.Date data = new java.sql.Date(conta.getDataCriacao().getTimeInMillis());
    		stmt.setDate(7, data);
    		stmt.setInt(8, conta.getIdConta());
    		
    		stmt.executeQuery();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	
    	
    }
    
    public Conta buscarPorId(int codigoBusca) {
    	Conta conta = null;
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		stmt = con.prepareStatement("SELECT * FROM T_CONTA WHERE id_conta = ?");
    		stmt.setInt(1, codigoBusca);
    		rs = stmt.executeQuery();
    		
    		if(rs.next()) {
    			int id = rs.getInt("id_conta");
    			String nome = rs.getString("nm_usuario");
    			String cpf = rs.getString("nr_cpf");
    			Double saldo = rs.getDouble("ds_balanco");
    			String email = rs.getString("ds_email");
    			String senha = rs.getString("ds_senha");
    			String telefone = rs.getString("nr_telefone");
    			java.sql.Date data = rs.getDate("dt_criacao");
    			Calendar dataCriacao = Calendar.getInstance();
    			dataCriacao.setTimeInMillis(data.getTime());
    			
    			conta = new Conta(nome, senha, cpf, email, telefone, dataCriacao, saldo, id);
    		}
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    			rs.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	return conta;
    };
    
    public Conta buscarPorEmail(String emailBusca) {
    	Conta conta = null;
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		stmt = con.prepareStatement("SELECT * FROM T_CONTA WHERE DS_EMAIL = ?");
    		stmt.setString(1, emailBusca);
    		rs = stmt.executeQuery();
    		
    		if(rs.next()) {
    			int id = rs.getInt("id_conta");
    			String nome = rs.getString("nm_usuario");
    			String cpf = rs.getString("nr_cpf");
    			Double saldo = rs.getDouble("ds_balanco");
    			String email = rs.getString("ds_email");
    			String senha = rs.getString("ds_senha");
    			String telefone = rs.getString("nr_telefone");
    			java.sql.Date data = rs.getDate("dt_criacao");
    			Calendar dataCriacao = Calendar.getInstance();
    			dataCriacao.setTimeInMillis(data.getTime());
    			
    			conta = new Conta(nome, senha, cpf, email, telefone, dataCriacao, saldo, id);
    		}
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    			rs.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	return conta;
    };

    
    @Override
    public boolean validarConta(Conta conta) {
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		stmt = con.prepareStatement("SELECT * FROM T_CONTA WHERE DS_EMAIL = ? AND DS_SENHA = ?");
    		stmt.setString(1, conta.getEmail());
    		stmt.setString(2, conta.getSenha());
    		rs = stmt.executeQuery();
    	
    		if(rs.next()){
    			System.out.println("Conta validada");
    			return true;
    		}
    		
    	}catch(SQLException e){
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			rs.close();
    			con.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	System.out.println("Conta não validada");
    	return false;
    }
}
