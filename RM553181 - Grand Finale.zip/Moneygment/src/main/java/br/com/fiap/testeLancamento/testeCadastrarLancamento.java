package br.com.fiap.testeLancamento;

import java.util.Calendar;

import br.com.fiap.bean.Conta;
import br.com.fiap.bean.Lancamento;
import br.com.fiap.dao.OracleContaDAO;
import br.com.fiap.dao.OracleLancamentoDAO;
import br.com.fiap.exception.DBException;

public class testeCadastrarLancamento {

	public static void main(String[] args) throws DBException {
		OracleLancamentoDAO dao = new OracleLancamentoDAO();
		OracleContaDAO contaDao = new OracleContaDAO();
		Conta conta1 = contaDao.buscarPorId(1);
		Lancamento receita1 = new Lancamento();
		receita1.setDescricao("Pagamento Boleto FIAP");
		receita1.setTipo("Despesa");
		receita1.setConta(conta1);
		receita1.setCategoria("Faculdade");
		receita1.setData(Calendar.getInstance());
		receita1.setValor(700);
		
		dao.cadastrar(receita1);
		
		System.out.println("Lancamento cadastrado!");
		

	}

}
