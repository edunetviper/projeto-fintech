package br.com.fiap.bean;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
/**
 * Classe que abstrai um lancamento
 * @author Eduardo Gonçalves
 * @version 1.0
 */

import br.com.fiap.exception.TipoDeLancamentoInvalidoException;

public class Lancamento implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	
	private double valor;
	
	private String descricao;
	
	private Calendar data;
	
	private String categoria;
	
	private String tipo;
	
	private Conta conta;
	
	public Lancamento() {
		
	}

	public Lancamento(int id, double valor, String descricao, Calendar data, String categoria, String tipo, Conta conta) {
		super();
		this.id = id;
		this.valor = valor;
		this.descricao = descricao;
		this.data = data;
		this.categoria = categoria;
		this.tipo = tipo;
		this.conta = conta;
	}
	
	public double getValor() {
		return valor;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public Calendar getData() {
		return data;
	}
	
	
	public String getCategoria() {
		return categoria;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setData(Calendar data) {
		this.data = data;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public int getIdLancamento() {
		return id;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		if(tipo.equals("Receita") || tipo.equals("Despesa")) {
			this.tipo = tipo;
		}else {
			throw new TipoDeLancamentoInvalidoException();
		}
	}
	
	public void setConta(Conta conta) {
		this.conta = conta;
	}
	
	public Conta getConta() {
		return conta;
	}
	

	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
		return "Lancamento [idLancamento=" + id + " | valor=" + valor + " | tipo=" + tipo + " | descricao=" + descricao + " | categoria=" + categoria + " | data=" + sdf.format(data.getTime()) + " | usuario=" + conta.getNome() + " | conta=" + conta.getIdConta()+ "]";
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getFmtCategoria() {
		String fmtCategoria = getCategoria().toUpperCase();
		return fmtCategoria;
	}


	

	
	
	
}
