package br.com.fiap.bean;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
/**
 * Classe que abstrai uma transacao
 * @author Eduardo Gonçalves
 * @version 1.0
 */


public class Transacao implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	
	private Calendar data;
	
	private Double valor;
	
	private String detalhes;

	private Conta contaOrigem;
	
	private Conta contaDestino;
	
	private Tipo_Transacao tipoTransacao;
	
	public Transacao() {
		
	}
	
	public Transacao(int id, Calendar data, double valor, Conta contaOrigem, Conta contaDestino, Tipo_Transacao tipoTransacao, String detalhes) {
		this.id = id;
		this.data = data;
		this.valor = valor;
		this.contaOrigem = contaOrigem;
		this.contaDestino = contaDestino;
		this.tipoTransacao = tipoTransacao;		
		this.detalhes = detalhes;
	}
	
	public int getId() {
		return id;
	}
	
	public Calendar getData() {
		return data;
	}
	
	public void setData(Calendar data) {
		this.data = data;
	}
	
	public Conta getContaOrigem() {
		return contaOrigem;
	}
	
	public void setContaOrigem(Conta contaOrigem) {
		this.contaOrigem = contaOrigem;
	}
	
	public Conta getContaDestino() {
		return contaDestino;
	}
	
	public void setContaDestino(Conta contaDestino) {
		this.contaDestino = contaDestino;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public Tipo_Transacao getTipoTransacao() {
		return tipoTransacao;
	}

	public void setTipoTransacao(Tipo_Transacao tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}
	
	
	public String getDetalhes() {
		return detalhes;
	}

	public void setDetalhes(String detalhes) {
		this.detalhes = detalhes;
	}

	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
		return "Transacao [id=" + id + " | data=" + sdf.format(data.getTime()) + " | valor=" + valor + " | contaOrigem=" + contaOrigem.getNome()
				+ " | contaDestino=" + contaDestino.getNome() + " | tipoTransacao=" + tipoTransacao.getTipo() + " | detalhes="+ detalhes +"]";
	}
	
	
	
}
