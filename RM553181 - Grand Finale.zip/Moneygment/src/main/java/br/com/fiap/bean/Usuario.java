package br.com.fiap.bean;

import java.io.Serializable;
import java.util.Calendar;

import br.com.fiap.utils.CriptografiaUtils;

/**
 * Classe que abstrai um usuário
 * @author Eduardo Gonçalves
 * @version 1.0
 */
public abstract class Usuario implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected String nome;
	
	protected String senha;
	
	protected String cpf;
	
	protected String email;
	
	protected String telefone;
	
	protected Calendar dataCriacao;
	
	public Usuario(){
		
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSenha() {
		return senha;
	}
	
	public void setSenha(String senha) {
		try {
			this.senha = CriptografiaUtils.criptografar(senha);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getTelefone() {
		return telefone;
	}
	
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	public void setDataCriacao(Calendar dataCriacao) {
		this.dataCriacao = dataCriacao;
	}
	
	public Calendar getDataCriacao() {
		return dataCriacao;
	}
	
	
	
	
	
}
