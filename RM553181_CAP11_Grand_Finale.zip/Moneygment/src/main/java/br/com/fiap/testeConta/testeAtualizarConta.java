package br.com.fiap.testeConta;

import br.com.fiap.bean.Conta;
import br.com.fiap.dao.OracleContaDAO;

public class testeAtualizarConta {

	public static void main(String[] args) {

		OracleContaDAO dao = new OracleContaDAO();
		
		Conta conta = dao.buscarPorEmail("edu@fiap.com");
		
		conta.setSenha("123456");
		
		dao.atualizar(conta);
		
		System.out.println("Conta atualizada!");

	}

}
