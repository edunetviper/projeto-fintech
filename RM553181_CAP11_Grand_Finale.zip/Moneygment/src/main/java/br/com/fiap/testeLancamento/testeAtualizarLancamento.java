package br.com.fiap.testeLancamento;

import java.util.Calendar;

import br.com.fiap.bean.Lancamento;
import br.com.fiap.dao.OracleLancamentoDAO;
import br.com.fiap.exception.DBException;

public class testeAtualizarLancamento {

	public static void main(String[] args) throws DBException {
		OracleLancamentoDAO dao = new OracleLancamentoDAO();
		
		Lancamento lancamento = dao.buscarPorId(1);
		lancamento.setData(Calendar.getInstance());
		lancamento.setValor(1450);
		
		dao.atualizar(lancamento);
		
		System.out.println("Lancamento atualizado!");

	}

}
