package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.fiap.bean.Conta;
import br.com.fiap.bean.Lancamento;
import br.com.fiap.exception.DBException;
import br.com.fiap.jdbc.DBManager;

public class OracleLancamentoDAO implements LancamentoDAO {
	
	private Connection con;

    public void cadastrar(Lancamento lancamento) throws DBException {
    	PreparedStatement stmt = null;
    	ContaDAO cDao = new OracleContaDAO();
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		String sql = "INSERT INTO t_lancamento(id_lancamento, tipo_lancamento, vl_lancamento, ds_lancamento, ds_categoria, dt_lancamento, id_conta) VALUES (SQ_LANCAMENTO.NEXTVAL, ?, ?, ?, ?, ?, ?) ";
    		stmt = con.prepareStatement(sql);
    		stmt.setString(1, lancamento.getTipo());
    		stmt.setDouble(2, lancamento.getValor());
    		stmt.setString(3, lancamento.getDescricao());
    		stmt.setString(4, lancamento.getCategoria());
    		java.sql.Date data = new java.sql.Date(lancamento.getData().getTimeInMillis());
    		stmt.setDate(5, data);
    		stmt.setInt(6, lancamento.getConta().getIdConta());
    		cDao.atualizarSaldoConta(lancamento.getConta());
    		stmt.executeUpdate();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    };
    
    public List<Lancamento> listar(){
    	List<Lancamento> lista = new ArrayList<Lancamento>();
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {

    		con = DBManager.getinstance().obterConexao();
    		String sql = "SELECT * FROM T_LANCAMENTO";
    		stmt = con.prepareStatement(sql);
    		rs = stmt.executeQuery();
    		OracleContaDAO contaDao = new OracleContaDAO();
    		
    		while(rs.next()) {
    			Conta conta = null;
    			int codigo = rs.getInt("ID_LANCAMENTO");
    			String tipo = rs.getString("TIPO_LANCAMENTO");
    			Double valor = rs.getDouble("VL_LANCAMENTO");
    			String descricao = rs.getString("DS_LANCAMENTO");
    			String categoria = rs.getString("DS_CATEGORIA");
    			java.sql.Date data = rs.getDate("DT_LANCAMENTO");
    			Calendar dataLancamento = Calendar.getInstance();
    			dataLancamento.setTimeInMillis(data.getTime());
    			int idConta = rs.getInt("ID_CONTA");
    			conta = contaDao.buscarPorId(idConta);
        		
    			
    			Lancamento lancamento = new Lancamento(codigo, valor, descricao, dataLancamento, categoria, tipo, conta);
    			
    			lista.add(lancamento);
    		}
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    			rs.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	return lista;
    };
    
    public List<Lancamento> listarPorConta(Conta c){
    	List<Lancamento> lista = new ArrayList<Lancamento>();
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {

    		con = DBManager.getinstance().obterConexao();
    		String sql = "SELECT * FROM T_LANCAMENTO WHERE ID_CONTA = ?";
    		stmt = con.prepareStatement(sql);
    		stmt.setInt(1, c.getIdConta());
    		rs = stmt.executeQuery();
    		OracleContaDAO contaDao = new OracleContaDAO();
    		
    		while(rs.next()) {
    			Conta conta = null;
    			int codigo = rs.getInt("ID_LANCAMENTO");
    			String tipo = rs.getString("TIPO_LANCAMENTO");
    			Double valor = rs.getDouble("VL_LANCAMENTO");
    			String descricao = rs.getString("DS_LANCAMENTO");
    			String categoria = rs.getString("DS_CATEGORIA");
    			java.sql.Date data = rs.getDate("DT_LANCAMENTO");
    			Calendar dataLancamento = Calendar.getInstance();
    			dataLancamento.setTimeInMillis(data.getTime());
    			int idConta = rs.getInt("ID_CONTA");
    			conta = contaDao.buscarPorId(idConta);
        		
    			
    			Lancamento lancamento = new Lancamento(codigo, valor, descricao, dataLancamento, categoria, tipo, conta);
    			
    			lista.add(lancamento);
    		}
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    			rs.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	return lista;
    };
    
    public void atualizar(Lancamento lancamento) throws DBException {
    	PreparedStatement stmt = null;
    	ContaDAO cDao = new OracleContaDAO();
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		String sql = "UPDATE T_LANCAMENTO SET tipo_lancamento = ?, vl_lancamento = ?, ds_lancamento = ?, ds_categoria = ?, dt_lancamento = ? WHERE id_lancamento = ?";
    		stmt = con.prepareStatement(sql);
    		stmt.setString(1, lancamento.getTipo());
    		stmt.setDouble(2, lancamento.getValor());
    		stmt.setString(3, lancamento.getDescricao());
    		stmt.setString(4, lancamento.getCategoria());
    		java.sql.Date data = new java.sql.Date(lancamento.getData().getTimeInMillis());
    		stmt.setDate(5, data);
    		stmt.setInt(6, lancamento.getIdLancamento());
    		cDao.atualizarSaldoConta(lancamento.getConta());
    		stmt.executeQuery();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    };
  
    public void remover(int codigo) throws DBException {
    	PreparedStatement stmt = null;
    	ContaDAO cDao = new OracleContaDAO();
    	Lancamento lancamento = null;
    	lancamento = buscarPorId(codigo);
    			
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		String sql = "DELETE FROM T_LANCAMENTO WHERE id_lancamento = ?";
    		stmt = con.prepareStatement(sql);
    		stmt.setInt(1, codigo);
    		cDao.atualizarSaldoConta(lancamento.getConta());
    		stmt.executeUpdate();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			stmt.close();
    			con.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    };
    
    public Lancamento buscarPorId(int codigoBusca) {
    	Lancamento lancamento = null;
    	PreparedStatement stmt = null;
    	ResultSet rs = null;
    	
    	try {
    		con = DBManager.getinstance().obterConexao();
    		String sql = "SELECT * FROM t_lancamento where id_lancamento = ?";
    		stmt = con.prepareStatement(sql);
    		stmt.setInt(1, codigoBusca);
    		rs = stmt.executeQuery();
    		OracleContaDAO contaDao = new OracleContaDAO();
    		
    		if(rs.next()) {
    			Conta conta = null;
    			int codigo = rs.getInt("ID_LANCAMENTO");
    			String tipo = rs.getString("TIPO_LANCAMENTO");
    			Double valor = rs.getDouble("VL_LANCAMENTO");
    			String descricao = rs.getString("DS_LANCAMENTO");
    			String categoria = rs.getString("DS_CATEGORIA");
    			java.sql.Date data = rs.getDate("DT_LANCAMENTO");
    			Calendar dataLancamento = Calendar.getInstance();
    			dataLancamento.setTimeInMillis(data.getTime());
    			int idConta = rs.getInt("ID_CONTA");
    			conta = contaDao.buscarPorId(idConta);
        		
    			lancamento = new Lancamento(codigo, valor, descricao, dataLancamento, categoria, tipo, conta);
    		}
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
    		try {
    			con.close();
    			stmt.close();
    			rs.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    	return lancamento;
    	
    };
    
}
