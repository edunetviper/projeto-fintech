package br.com.fiap.testeConta;

import br.com.fiap.dao.OracleContaDAO;

public class testeRemocaoConta {

	public static void main(String[] args) {
		
		OracleContaDAO dao = new OracleContaDAO();
		
		dao.remover(4);
		
		System.out.println("Conta removida!");

	}

}
