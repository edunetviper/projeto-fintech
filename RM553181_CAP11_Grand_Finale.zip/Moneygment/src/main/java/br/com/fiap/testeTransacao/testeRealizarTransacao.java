package br.com.fiap.testeTransacao;

import java.sql.SQLException;
import java.util.Calendar;

import br.com.fiap.bean.Conta;
import br.com.fiap.bean.Tipo_Transacao;
import br.com.fiap.bean.Transacao;
import br.com.fiap.dao.OracleContaDAO;
import br.com.fiap.dao.OracleTipoTransacao;
import br.com.fiap.dao.OracleTransacaoDAO;

public class testeRealizarTransacao {

	public static void main(String[] args) {
		
		OracleTransacaoDAO dao = new OracleTransacaoDAO();
		OracleContaDAO contaDao = new OracleContaDAO();
		OracleTipoTransacao tipoDao = new OracleTipoTransacao();
		
		Conta conta1 = contaDao.buscarPorId(1);
		Conta conta2 = contaDao.buscarPorId(6);
		Tipo_Transacao PIX = tipoDao.buscarPorId(2);
		
		Transacao transacao1 = new Transacao();
		
		transacao1.setContaOrigem(conta1);
		transacao1.setContaDestino(conta2);
		transacao1.setValor(200.00);
		transacao1.setData(Calendar.getInstance());
		transacao1.setDetalhes("Pagamento agiota");
		transacao1.setTipoTransacao(PIX);	
		
		try{
			dao.cadastrar(transacao1);
			System.out.println("Transacao realizada!");
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
