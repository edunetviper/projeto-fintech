package br.com.fiap.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Classe que abstrai uma conta de usuário
 * @author Eduardo Gonçalves
 * @version 1.0
 */
public class Conta extends Usuario implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int idConta;

	private double saldo;
	
	public Conta() {
		
	}

	public Conta(String nome, String senha, String cpf, String email, String telefone, Calendar dataCriacao, double saldo, int idConta) {
		this.nome = nome;
		setSenha(senha);
		this.cpf = cpf;
		this.email = email;
		this.telefone = telefone;
		this.dataCriacao = dataCriacao;
		this.saldo = saldo;
		this.idConta = idConta;
	}
	
	public Conta(String email, String senha) {
		this.email = email;
		setSenha(senha);
	}

	public int getIdConta() {
		return idConta;
	}


	public double getSaldo() {
		return saldo;
	}

	
	/**
	 * Remove um valor do saldo da conta
	 * @param valor O valor à ser removido
	 */
	public void sacar(double valor) {
        if (valor > this.saldo) {
            throw new RuntimeException("Valor maior do que saldo");
        }
        this.saldo -= valor;
    }
	
	/**
	 * Adiciona um valor ao saldo da conta
	 * @param valor Valor à ser adicionado
	 */
    public void depositar(double valor) {
        if (valor <= 0) {
            throw new RuntimeException("Valor menor ou igual a zero");
        }
        this.saldo += valor;
    }
   

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
		return "Conta [idConta=" + idConta + "| nome=" + nome + "| senha=" + senha +  "| saldo=" + saldo + "| cpf="+ cpf + "| email="+ email +"| telefone=" + telefone +"| data de criação ="+sdf.format(dataCriacao.getTime())
				+"]";
	}
	

}
