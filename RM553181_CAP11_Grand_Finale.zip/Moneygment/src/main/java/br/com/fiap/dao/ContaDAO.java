package br.com.fiap.dao;

import java.util.List;

import br.com.fiap.bean.Conta;

public interface ContaDAO {
    public void cadastrar(Conta conta);
    
    public List<Conta> listar();
    
    public void atualizar(Conta conta);
  
    public void remover(int codigo);
    
    public Conta buscarPorId(int codigoBusca);
    
    public Conta buscarPorEmail(String emailBusca);
    
    boolean validarConta(Conta conta);
    
    public void atualizarSaldoConta(Conta conta);
}
