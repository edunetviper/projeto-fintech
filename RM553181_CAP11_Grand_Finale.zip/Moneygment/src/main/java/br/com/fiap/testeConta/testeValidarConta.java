package br.com.fiap.testeConta;

import br.com.fiap.bean.Conta;
import br.com.fiap.dao.ContaDAO;
import br.com.fiap.factory.DAOFactory;

public class testeValidarConta {

	public static void main(String[] args) {
		ContaDAO dao;
		dao = DAOFactory.getContaDAO();
		
		Conta conta = null;
		conta = new Conta("edu@fiap.com", "123456");
		System.out.println(conta.getSenha().toString());
		
		dao.validarConta(conta);
		
	}

}
