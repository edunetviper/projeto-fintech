package br.com.fiap.testeLancamento;

import br.com.fiap.dao.OracleLancamentoDAO;
import br.com.fiap.exception.DBException;

public class testeRemocaoLancamento {

	public static void main(String[] args) throws DBException {
		OracleLancamentoDAO dao = new OracleLancamentoDAO();
		
		dao.remover(28);
		
		System.out.println("Lancamento removido!");

	}

}
