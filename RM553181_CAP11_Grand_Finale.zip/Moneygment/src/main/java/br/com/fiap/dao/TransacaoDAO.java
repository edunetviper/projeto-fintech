package br.com.fiap.dao;

import java.sql.SQLException;
import java.util.List;

import br.com.fiap.bean.Transacao;


public interface TransacaoDAO{
	
	public void cadastrar(Transacao Transacao) throws SQLException, ClassNotFoundException ;
    
    public List<Transacao> listar();
    
    public Transacao buscarPorId(int codigoBusca);
}
