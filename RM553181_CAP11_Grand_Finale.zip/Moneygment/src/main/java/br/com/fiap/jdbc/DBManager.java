package br.com.fiap.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {
	private static final String DB_DRIVER_CLASS = "oracle.jdbc.driver.OracleDriver";
	private static final String DB_URL = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
	private static final String DB_USERNAME = "RM553181";
	private static final String DB_PASSWORD = "757879";
			
	private static DBManager instance;
	
	private DBManager(){
		
	}
	
	public static DBManager getinstance() {
		if (instance == null) {
			instance = new DBManager();
		}
		return instance;
	}
	
	public Connection obterConexao() {
		Connection con = null;
		try {
			Class.forName(DB_DRIVER_CLASS);
			
			con = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD);
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
