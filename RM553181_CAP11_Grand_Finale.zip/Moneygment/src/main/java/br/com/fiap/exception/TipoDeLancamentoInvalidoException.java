package br.com.fiap.exception;

public class TipoDeLancamentoInvalidoException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TipoDeLancamentoInvalidoException() {
		System.err.println("Não é possível aceitar nenhum outro tipo de lancamento além das strings 'Receita' ou 'Despesa' ");
	}
}
